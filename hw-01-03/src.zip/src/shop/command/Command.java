package shop.command;

public interface Command {
    boolean run();
}
