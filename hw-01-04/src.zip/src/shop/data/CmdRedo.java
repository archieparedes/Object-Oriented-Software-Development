package shop.data;

public class CmdRedo {
}
