package shop.data;

public class CmdUndo {
}
